import "./App.css";
import { Routes, Route } from "react-router-dom";
// import { Navbar } from "./components/navbar/Navbar";
import { SignIn } from "./components/auth/signin";

// authentication
import { auth } from "./firebase/firebase";
import { useDispatch, useSelector } from "react-redux";
import { useEffect } from "react";
import { LOGGED_IN_USER } from "./reduxStore/actionType";
import { Create } from "./components/auth/create";

import { Blogs_before_login } from "./components/Before_login/Blogs_before_login";
import { Blogs_after_login } from "./components/After_login/Blogs_after_login";
import { FilterTag } from "./components/After_login/filter_by_tag";

// import { NavbarBeforeLogin } from "./components/Before_login/navbar_before_login";

import {YourStories} from './components/yourStories/yourStories'
import {WriteBlog}  from "./components/writeBlog/writeBlog"
import {OpenBlog} from "./components/yourStories/openBlog"

function App() {
  const dispatch = useDispatch();
  useEffect(async () => {
    const userAuth = auth.onAuthStateChanged(async (user) => {
      if (user) {
        // const { displayName, photoURL } = user._delegate;
        const { token, claims } = await user.getIdTokenResult();
        const { name, picture } = claims;
        console.log(claims);
        dispatch({
          type: LOGGED_IN_USER,
          payload: {
            email: user.email,
            name,
            picture,
            token,
          },
        });
      }
    });

    return () => userAuth();
  }, []);

  return (
    <div className="App">
      {/* routes-abhishek */}
      {/* <Navbar />
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/about" element={<About />} />
        <Route path="/counter" element={<Counter />} />
        <Route path="/signin" element={<SignIn />} />
        <Route path="/create" element={<Create />} />

      </Routes> */}
      {/* homepage routes-ritesh */}
      {/* <NavbarBeforeLogin/> */}
      <Routes>
        <Route path={"/"} element={<Blogs_before_login />}></Route>
        <Route path={"/loggedIn"} element={<Blogs_after_login />}></Route>
        <Route path={"/tags"} element={<FilterTag />}></Route>
        <Route path="/signin" element={<SignIn/>}></Route>
        <Route path="/create" element={<Create/>}></Route>
      <Route path="/stories/*" element={<YourStories />}></Route>
      <Route path="/writeBlog" element={<WriteBlog />}></Route>
      <Route path='/openblog/:id' element={<OpenBlog />}></Route>
      </Routes>

      {/* routes-roshan */}
      {/* <Navbar/>
    <Routes>
      <Route path="/" element={<Home/>}/>
      <Route path="/about" element={<About/>}/>
      <Route path="/counter" element={<Counter/>}/>

    </Routes> */}
      {/* aditya-routes */}
      {/* <Routes>
        <Route path="/" element={<Home />}></Route>
        <Route path="/ourstory" element={<OurStory />}></Route>
        <Route path="/membership" element={<MemberShip />}></Route>
        <Route path="/write" element={<Write />}></Route>
        <Route path="/signin" element={<SignIn />}></Route>
      </Routes> */}
    </div>
  );
}

export default App;
