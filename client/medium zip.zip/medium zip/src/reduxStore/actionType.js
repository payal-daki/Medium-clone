export const INC = "INC_COUNT";
export const DEC = "DEC_COUNT";
export const LOGGED_IN_USER = "LOGGED_IN_USER";
export const LOGOUT = "LOGOUT";
export const LIKE = "LIKE"
export const INDIVIDUAL_PAGE = "INDIVIDUAL_PAGE"
