import { LIKE,INDIVIDUAL_PAGE } from "../actionType";

const initstate = {
    allelements:[],
    likes:[]
    };
    
    export const homeReducer = (state = initstate , {type,payload})=>{
        switch(type){
            case LIKE:{
                return{
                    ...state,
                    LIKES:[...state.likes,payload]
                }
            }
            case INDIVIDUAL_PAGE:{
                return{
                    ...state,
                    Individual_data:[payload]
                }
            }
            
            default:
                return state;
        }
    }