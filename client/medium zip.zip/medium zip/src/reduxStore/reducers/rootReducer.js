import { combineReducers } from "redux";
import { reducer } from "./reducer";
import { userReducer } from "./userReducer";
import { homeReducer } from "./homeReducer";

const rootReducer = combineReducers({
  reducer,
  user: userReducer,
  homeReducer,
});

export default rootReducer;
