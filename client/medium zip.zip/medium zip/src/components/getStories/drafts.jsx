import "./getStories.css"

export const Drafts = () => {
    return (
        <div className="parentDiv">

            <div className="childDiv">
            <p>You have no drafts.</p>
            <p>Write a story on Medium.</p>
            
            </div>
        </div>
    )
}