export const Responses = () => {
    return (
        <div className="childDiv">
            No responces
        </div>
    )
}